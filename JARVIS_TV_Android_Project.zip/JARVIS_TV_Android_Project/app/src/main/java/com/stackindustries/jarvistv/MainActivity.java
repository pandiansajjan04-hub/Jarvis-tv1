package com.stackindustries.jarvistv;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String API_URL = "https://jarvis-android-nv0u.onrender.com/api/chat";
    private final int BG = Color.rgb(5, 10, 24);
    private final int PANEL = Color.rgb(12, 22, 43);
    private final int CYAN = Color.rgb(42, 211, 255);
    private TextView status, transcript;
    private EditText input;
    private Button send, voice;
    private ScrollView scroll;
    private ExecutorService worker;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private boolean ttsReady = false;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                             WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        worker = Executors.newSingleThreadExecutor();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.US);
                ttsReady = true;
            }
        });
        buildUi();
    }

    private GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(22f);
        d.setStroke(2, stroke);
        return d;
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextColor(color); v.setTextSize(size);
        v.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private void buildUi() {
        LinearLayout base = new LinearLayout(this);
        base.setOrientation(LinearLayout.VERTICAL);
        base.setPadding(52, 30, 52, 30);
        base.setBackgroundColor(BG);
        setContentView(base);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = label("J.A.R.V.I.S", 30, CYAN, true);
        header.addView(brand, new LinearLayout.LayoutParams(0, 64, 1));
        status = label("● SYSTEM ONLINE  |  KTC TV", 16, Color.GREEN, true);
        header.addView(status);
        base.addView(header);

        TextView sub = label("PERSONAL AI ASSISTANT  •  ADVANCED INTERFACE", 13,
                Color.rgb(143, 176, 205), true);
        base.addView(sub);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
        cp.topMargin = 22; cp.bottomMargin = 18;
        base.addView(content, cp);

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setGravity(Gravity.CENTER);
        left.setBackground(shape(PANEL, Color.rgb(24, 93, 130)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, 0.9f);
        lp.rightMargin = 20;
        content.addView(left, lp);
        TextView orb = label("◉", 116, CYAN, true);
        orb.setGravity(Gravity.CENTER);
        left.addView(orb);
        TextView core = label("JARVIS CORE", 22, Color.WHITE, true);
        core.setGravity(Gravity.CENTER);
        left.addView(core);
        TextView ready = label("VOICE & AI SYSTEM READY", 13,
                Color.rgb(117, 190, 220), true);
        ready.setGravity(Gravity.CENTER);
        left.addView(ready);

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setPadding(22, 16, 22, 16);
        right.setBackground(shape(PANEL, Color.rgb(24, 66, 98)));
        content.addView(right, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, 1.5f));
        right.addView(label("CONVERSATION", 17, CYAN, true));
        scroll = new ScrollView(this);
        transcript = label("JARVIS: Good day. Systems are ready. How may I assist you?",
                19, Color.WHITE, false);
        transcript.setGravity(Gravity.TOP);
        transcript.setPadding(4, 16, 4, 12);
        scroll.addView(transcript);
        right.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.GRAY);
        input.setHint("Ask JARVIS something...");
        input.setTextSize(18);
        input.setPadding(18, 8, 18, 8);
        input.setBackground(shape(Color.rgb(18, 32, 54), CYAN));
        controls.addView(input, new LinearLayout.LayoutParams(0, 58, 1));
        send = button("SEND");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(112, 58);
        bp.leftMargin = 12;
        controls.addView(send, bp);
        voice = button("VOICE");
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(112, 58);
        vp.leftMargin = 10;
        controls.addView(voice, vp);
        base.addView(controls);

        send.setOnClickListener(v -> submit());
        voice.setOnClickListener(v -> startVoice());
        input.setOnEditorActionListener((v, action, event) -> { submit(); return true; });
        send.setNextFocusLeftId(input.getId());
        input.setNextFocusRightId(send.getId());
        voice.setNextFocusLeftId(send.getId());
        input.requestFocus();
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(shape(Color.rgb(10, 95, 135), CYAN));
        b.setFocusable(true);
        return b;
    }

    private void append(String who, String message) {
        transcript.append("\n\n" + who + ": " + message);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void submit() {
        String message = input.getText().toString().trim();
        if (message.isEmpty()) return;
        input.setText("");
        append("YOU", message);
        status.setText("● CONNECTING TO JARVIS");
        send.setEnabled(false);
        worker.execute(() -> {
            String reply;
            try { reply = callBackend(message); }
            catch (Exception e) { reply = "I couldn't reach the AI service. Please check the Render service and try again."; }
            final String answer = reply;
            runOnUiThread(() -> {
                append("JARVIS", answer);
                status.setText("● SYSTEM ONLINE");
                send.setEnabled(true);
                if (ttsReady) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "jarvis-reply");
                input.requestFocus();
            });
        });
    }

    private String callBackend(String message) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(API_URL).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(25000);
        c.setReadTimeout(45000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        JSONObject body = new JSONObject();
        body.put("message", message);
        try (OutputStream out = c.getOutputStream()) {
            out.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = c.getResponseCode();
        InputStream stream = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
        StringBuilder raw = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line; while ((line = r.readLine()) != null) raw.append(line);
        }
        c.disconnect();
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + raw);
        JSONObject obj = new JSONObject(raw.toString());
        String[] keys = {"reply", "response", "message", "output", "content"};
        for (String key : keys) if (obj.has(key) && !obj.isNull(key)) return obj.getString(key);
        if (obj.has("choices")) {
            JSONArray choices = obj.getJSONArray("choices");
            if (choices.length() > 0) return choices.getJSONObject(0)
                    .getJSONObject("message").getString("content");
        }
        return raw.toString();
    }

    private void startVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            append("JARVIS", "Voice recognition is not available on this TV. You can still type commands.");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 41);
            return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new android.speech.RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle p) { status.setText("● LISTENING"); }
            @Override public void onResults(Bundle b) {
                ArrayList<String> results = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (results != null && !results.isEmpty()) {
                    input.setText(results.get(0)); submit();
                }
                status.setText("● SYSTEM ONLINE");
            }
            @Override public void onError(int e) {
                status.setText("● SYSTEM ONLINE");
                append("JARVIS", "I couldn't hear that. Please try again or type your request.");
            }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float v) {}
            @Override public void onBufferReceived(byte[] b) {}
            @Override public void onEndOfSpeech() {}
            @Override public void onPartialResults(Bundle b) {}
            @Override public void onEvent(int a, Bundle b) {}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toString());
        recognizer.startListening(i);
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) { startVoice(); return true; }
        return super.onKeyDown(keyCode, event);
    }

    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (worker != null) worker.shutdownNow();
        super.onDestroy();
    }
}
