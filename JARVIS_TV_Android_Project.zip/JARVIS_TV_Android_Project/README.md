# JARVIS TV — Android project

Target: Android 11 / API 30, `armeabi-v7a` compatible, landscape 1920x1080.

## Included
- Native Android TV launcher activity with Leanback launcher category
- TV remote focusable controls
- Text chat to `https://jarvis-android-nv0u.onrender.com/api/chat`
- Speech input using Android speech recognition (requires a microphone and a recognition service)
- Spoken responses using Android TextToSpeech
- No OpenAI key is stored in the APK

## Important backend contract
The app currently sends:
```json
{"message":"your text"}
```
to `/api/chat` and reads a response from `reply`, `response`, `message`, `output`, or `content` (or standard OpenAI `choices[0].message.content`).
If your existing Express route expects a different request field or returns a different JSON shape, adjust `callBackend()` in `MainActivity.java` to match it. The homepage loading does not by itself verify the chat API.

## Build on an Android phone
Use an Android IDE that can build Gradle Android projects, or Android Studio on a computer:
1. Open/import this folder as a Gradle project.
2. Use JDK 17 and Android Gradle Plugin 8.2.2.
3. Install Android SDK Platform 34 and Build Tools.
4. Build > Build APK(s) > Build APK(s).
5. The debug APK will be under `app/build/outputs/apk/debug/`.

This environment did not have Android SDK/Gradle installed, so this ZIP is project source, not a compiled APK.

## Install through Bugjaeger
After you build the APK, use Bugjaeger’s APK install action and select the APK file. Keep the TV and phone on the same network for ADB.

## Optional cloud build using GitHub Actions
This project includes `.github/workflows/build-apk.yml`. If you upload the project contents to a GitHub repository's `main` branch, the workflow builds a debug APK and publishes it as an Actions artifact. In the repository, open Actions > Build JARVIS TV APK > latest successful run > Artifacts > JARVIS-TV-debug-APK.
